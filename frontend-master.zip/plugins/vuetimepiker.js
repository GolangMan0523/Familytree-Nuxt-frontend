import Vue from 'vue'; 
import VueTimepicker from 'vue2-timepicker'
import 'vue2-timepicker/dist/VueTimepicker.css'
Vue.component('VueTimepicker', VueTimepicker)