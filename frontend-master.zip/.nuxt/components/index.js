import { wrapFunctional } from './utils'

export { default as 404 } from '../..\\components\\404.vue'
export { default as BarChart } from '../..\\components\\BarChart.js'
export { default as Chart } from '../..\\components\\Chart.vue'
export { default as Logo } from '../..\\components\\Logo.vue'
export { default as PieChart } from '../..\\components\\PieChart.js'
export { default as Search } from '../..\\components\\Search.vue'
export { default as ChatMessageDropdown } from '../..\\components\\chat\\MessageDropdown.vue'

export const Lazy404 = import('../..\\components\\404.vue' /* webpackChunkName: "components/404" */).then(c => wrapFunctional(c.default || c))
export const LazyBarChart = import('../..\\components\\BarChart.js' /* webpackChunkName: "components/bar-chart" */).then(c => wrapFunctional(c.default || c))
export const LazyChart = import('../..\\components\\Chart.vue' /* webpackChunkName: "components/chart" */).then(c => wrapFunctional(c.default || c))
export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c))
export const LazyPieChart = import('../..\\components\\PieChart.js' /* webpackChunkName: "components/pie-chart" */).then(c => wrapFunctional(c.default || c))
export const LazySearch = import('../..\\components\\Search.vue' /* webpackChunkName: "components/search" */).then(c => wrapFunctional(c.default || c))
export const LazyChatMessageDropdown = import('../..\\components\\chat\\MessageDropdown.vue' /* webpackChunkName: "components/chat-message-dropdown" */).then(c => wrapFunctional(c.default || c))
