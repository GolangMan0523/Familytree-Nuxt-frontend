import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  404: () => import('../..\\components\\404.vue' /* webpackChunkName: "components/404" */).then(c => wrapFunctional(c.default || c)),
  BarChart: () => import('../..\\components\\BarChart.js' /* webpackChunkName: "components/bar-chart" */).then(c => wrapFunctional(c.default || c)),
  Chart: () => import('../..\\components\\Chart.vue' /* webpackChunkName: "components/chart" */).then(c => wrapFunctional(c.default || c)),
  Logo: () => import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c)),
  PieChart: () => import('../..\\components\\PieChart.js' /* webpackChunkName: "components/pie-chart" */).then(c => wrapFunctional(c.default || c)),
  Search: () => import('../..\\components\\Search.vue' /* webpackChunkName: "components/search" */).then(c => wrapFunctional(c.default || c)),
  ChatMessageDropdown: () => import('../..\\components\\chat\\MessageDropdown.vue' /* webpackChunkName: "components/chat-message-dropdown" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
