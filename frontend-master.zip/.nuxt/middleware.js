const middleware = {}

middleware['guest'] = require('..\\middleware\\guest.js')
middleware['guest'] = middleware['guest'].default || middleware['guest']

middleware['permission'] = require('..\\middleware\\permission.js')
middleware['permission'] = middleware['permission'].default || middleware['permission']

middleware['verification'] = require('..\\middleware\\verification.js')
middleware['verification'] = middleware['verification'].default || middleware['verification']

export default middleware
