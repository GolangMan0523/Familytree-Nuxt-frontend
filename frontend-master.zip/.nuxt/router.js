import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2f209b54 = () => interopDefault(import('..\\pages\\addr\\index.vue' /* webpackChunkName: "pages/addr/index" */))
const _17751eba = () => interopDefault(import('..\\pages\\author\\index.vue' /* webpackChunkName: "pages/author/index" */))
const _6484b732 = () => interopDefault(import('..\\pages\\calendar\\index.vue' /* webpackChunkName: "pages/calendar/index" */))
const _dc5a7b92 = () => interopDefault(import('..\\pages\\cancel.vue' /* webpackChunkName: "pages/cancel" */))
const _7ffeed53 = () => interopDefault(import('..\\pages\\chan\\index.vue' /* webpackChunkName: "pages/chan/index" */))
const _39466556 = () => interopDefault(import('..\\pages\\chat.vue' /* webpackChunkName: "pages/chat" */))
const _3eaac230 = () => interopDefault(import('..\\pages\\chatroom.vue' /* webpackChunkName: "pages/chatroom" */))
const _6231611e = () => interopDefault(import('..\\pages\\citation\\index.vue' /* webpackChunkName: "pages/citation/index" */))
const _5b82c372 = () => interopDefault(import('..\\pages\\company\\index.vue' /* webpackChunkName: "pages/company/index" */))
const _367a96e7 = () => interopDefault(import('..\\pages\\dashboard.vue' /* webpackChunkName: "pages/dashboard" */))
const _6762602a = () => interopDefault(import('..\\pages\\dna.vue' /* webpackChunkName: "pages/dna" */))
const _c627b20a = () => interopDefault(import('..\\pages\\dnamatching\\index.vue' /* webpackChunkName: "pages/dnamatching/index" */))
const _c2256412 = () => interopDefault(import('..\\pages\\dnaupload\\index.vue' /* webpackChunkName: "pages/dnaupload/index" */))
const _7e9fe0ec = () => interopDefault(import('..\\pages\\emailverification.vue' /* webpackChunkName: "pages/emailverification" */))
const _4508e316 = () => interopDefault(import('..\\pages\\event\\index.vue' /* webpackChunkName: "pages/event/index" */))
const _3add197e = () => interopDefault(import('..\\pages\\family\\index.vue' /* webpackChunkName: "pages/family/index" */))
const _3a678219 = () => interopDefault(import('..\\pages\\familyevent\\index.vue' /* webpackChunkName: "pages/familyevent/index" */))
const _3c6c219c = () => interopDefault(import('..\\pages\\familyslgs\\index.vue' /* webpackChunkName: "pages/familyslgs/index" */))
const _1ca6ab10 = () => interopDefault(import('..\\pages\\files\\index.vue' /* webpackChunkName: "pages/files/index" */))
const _3bf0a77b = () => interopDefault(import('..\\pages\\forgotpassword.vue' /* webpackChunkName: "pages/forgotpassword" */))
const _120a698e = () => interopDefault(import('..\\pages\\forum\\index.vue' /* webpackChunkName: "pages/forum/index" */))
const _d05d4460 = () => interopDefault(import('..\\pages\\forumcategory\\index.vue' /* webpackChunkName: "pages/forumcategory/index" */))
const _e593cb92 = () => interopDefault(import('..\\pages\\forumtopic\\index.vue' /* webpackChunkName: "pages/forumtopic/index" */))
const _9662b46c = () => interopDefault(import('..\\pages\\gedcom\\index.vue' /* webpackChunkName: "pages/gedcom/index" */))
const _6038ff49 = () => interopDefault(import('..\\pages\\gedcom-export\\index.vue' /* webpackChunkName: "pages/gedcom-export/index" */))
const _785b8288 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _423ba98c = () => interopDefault(import('..\\pages\\mediaobject\\index.vue' /* webpackChunkName: "pages/mediaobject/index" */))
const _8972e4e0 = () => interopDefault(import('..\\pages\\mediaobjectfile\\index.vue' /* webpackChunkName: "pages/mediaobjectfile/index" */))
const _1010a69a = () => interopDefault(import('..\\pages\\note\\index.vue' /* webpackChunkName: "pages/note/index" */))
const _6c1712ea = () => interopDefault(import('..\\pages\\permissions\\index.vue' /* webpackChunkName: "pages/permissions/index" */))
const _cb54faa0 = () => interopDefault(import('..\\pages\\person\\index.vue' /* webpackChunkName: "pages/person/index" */))
const _4cc7d54d = () => interopDefault(import('..\\pages\\personalia\\index.vue' /* webpackChunkName: "pages/personalia/index" */))
const _92032706 = () => interopDefault(import('..\\pages\\personanci\\index.vue' /* webpackChunkName: "pages/personanci/index" */))
const _36ada4e2 = () => interopDefault(import('..\\pages\\personasso\\index.vue' /* webpackChunkName: "pages/personasso/index" */))
const _8816068e = () => interopDefault(import('..\\pages\\persondesi\\index.vue' /* webpackChunkName: "pages/persondesi/index" */))
const _133ec00a = () => interopDefault(import('..\\pages\\personevent\\index.vue' /* webpackChunkName: "pages/personevent/index" */))
const _175f9089 = () => interopDefault(import('..\\pages\\personlds\\index.vue' /* webpackChunkName: "pages/personlds/index" */))
const _01374045 = () => interopDefault(import('..\\pages\\personname\\index.vue' /* webpackChunkName: "pages/personname/index" */))
const _0e2232f6 = () => interopDefault(import('..\\pages\\personnamefone\\index.vue' /* webpackChunkName: "pages/personnamefone/index" */))
const _f418a932 = () => interopDefault(import('..\\pages\\personnameromn\\index.vue' /* webpackChunkName: "pages/personnameromn/index" */))
const _65bff763 = () => interopDefault(import('..\\pages\\personsubm\\index.vue' /* webpackChunkName: "pages/personsubm/index" */))
const _5ca65c30 = () => interopDefault(import('..\\pages\\place\\index.vue' /* webpackChunkName: "pages/place/index" */))
const _626ee89b = () => interopDefault(import('..\\pages\\privacy.vue' /* webpackChunkName: "pages/privacy" */))
const _136a563c = () => interopDefault(import('..\\pages\\profile.vue' /* webpackChunkName: "pages/profile" */))
const _83bba03a = () => interopDefault(import('..\\pages\\publication\\index.vue' /* webpackChunkName: "pages/publication/index" */))
const _72602a6c = () => interopDefault(import('..\\pages\\refn\\index.vue' /* webpackChunkName: "pages/refn/index" */))
const _a478dec0 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _015edbca = () => interopDefault(import('..\\pages\\repository\\index.vue' /* webpackChunkName: "pages/repository/index" */))
const _c0b0e31c = () => interopDefault(import('..\\pages\\roles\\index.vue' /* webpackChunkName: "pages/roles/index" */))
const _5695167d = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _14571e2a = () => interopDefault(import('..\\pages\\source\\index.vue' /* webpackChunkName: "pages/source/index" */))
const _05e70040 = () => interopDefault(import('..\\pages\\sourcedata\\index.vue' /* webpackChunkName: "pages/sourcedata/index" */))
const _5550dfe6 = () => interopDefault(import('..\\pages\\sourcedataeven\\index.vue' /* webpackChunkName: "pages/sourcedataeven/index" */))
const _23c83592 = () => interopDefault(import('..\\pages\\sourceref\\index.vue' /* webpackChunkName: "pages/sourceref/index" */))
const _c3e71d46 = () => interopDefault(import('..\\pages\\sourcerefeven\\index.vue' /* webpackChunkName: "pages/sourcerefeven/index" */))
const _2908e778 = () => interopDefault(import('..\\pages\\sourcerepo\\index.vue' /* webpackChunkName: "pages/sourcerepo/index" */))
const _7cca2f98 = () => interopDefault(import('..\\pages\\subm\\index.vue' /* webpackChunkName: "pages/subm/index" */))
const _f7085612 = () => interopDefault(import('..\\pages\\subn\\index.vue' /* webpackChunkName: "pages/subn/index" */))
const _6650ffa8 = () => interopDefault(import('..\\pages\\subscription\\index.vue' /* webpackChunkName: "pages/subscription/index" */))
const _858b60d4 = () => interopDefault(import('..\\pages\\success.vue' /* webpackChunkName: "pages/success" */))
const _ac971236 = () => interopDefault(import('..\\pages\\termsandconditions.vue' /* webpackChunkName: "pages/termsandconditions" */))
const _81efb4f2 = () => interopDefault(import('..\\pages\\tree\\index.vue' /* webpackChunkName: "pages/tree/index" */))
const _10f11376 = () => interopDefault(import('..\\pages\\verify-email.vue' /* webpackChunkName: "pages/verify-email" */))
const _46b1cc2c = () => interopDefault(import('..\\pages\\addr\\create.vue' /* webpackChunkName: "pages/addr/create" */))
const _0239f978 = () => interopDefault(import('..\\pages\\author\\create.vue' /* webpackChunkName: "pages/author/create" */))
const _b0d9f06a = () => interopDefault(import('..\\pages\\chan\\create.vue' /* webpackChunkName: "pages/chan/create" */))
const _0baf0d60 = () => interopDefault(import('..\\pages\\citation\\create.vue' /* webpackChunkName: "pages/citation/create" */))
const _3c89f58c = () => interopDefault(import('..\\pages\\company\\create.vue' /* webpackChunkName: "pages/company/create" */))
const _6670bba7 = () => interopDefault(import('..\\pages\\dnaupload\\create.vue' /* webpackChunkName: "pages/dnaupload/create" */))
const _0caaea2e = () => interopDefault(import('..\\pages\\event\\create.vue' /* webpackChunkName: "pages/event/create" */))
const _d15d80c6 = () => interopDefault(import('..\\pages\\family\\create.vue' /* webpackChunkName: "pages/family/create" */))
const _3a3d0bc5 = () => interopDefault(import('..\\pages\\familyevent\\create.vue' /* webpackChunkName: "pages/familyevent/create" */))
const _78cc5ca2 = () => interopDefault(import('..\\pages\\familyslgs\\create.vue' /* webpackChunkName: "pages/familyslgs/create" */))
const _ebe2b224 = () => interopDefault(import('..\\pages\\forumcategory\\create.vue' /* webpackChunkName: "pages/forumcategory/create" */))
const _41417767 = () => interopDefault(import('..\\pages\\forumtopic\\create.vue' /* webpackChunkName: "pages/forumtopic/create" */))
const _2cedd2b2 = () => interopDefault(import('..\\pages\\mediaobject\\create.vue' /* webpackChunkName: "pages/mediaobject/create" */))
const _558121a4 = () => interopDefault(import('..\\pages\\mediaobjectfile\\create.vue' /* webpackChunkName: "pages/mediaobjectfile/create" */))
const _2eb2346b = () => interopDefault(import('..\\pages\\note\\create.vue' /* webpackChunkName: "pages/note/create" */))
const _7eb50b63 = () => interopDefault(import('..\\pages\\pedigree\\data.js' /* webpackChunkName: "pages/pedigree/data" */))
const _4dd0cf02 = () => interopDefault(import('..\\pages\\pedigree\\show.vue' /* webpackChunkName: "pages/pedigree/show" */))
const _4fe1c3e4 = () => interopDefault(import('..\\pages\\person\\create.vue' /* webpackChunkName: "pages/person/create" */))
const _73e71f11 = () => interopDefault(import('..\\pages\\personalia\\create.vue' /* webpackChunkName: "pages/personalia/create" */))
const _50836de1 = () => interopDefault(import('..\\pages\\personanci\\create.vue' /* webpackChunkName: "pages/personanci/create" */))
const _72897bc8 = () => interopDefault(import('..\\pages\\personasso\\create.vue' /* webpackChunkName: "pages/personasso/create" */))
const _2b4235b6 = () => interopDefault(import('..\\pages\\persondesi\\create.vue' /* webpackChunkName: "pages/persondesi/create" */))
const _7c4d8bf4 = () => interopDefault(import('..\\pages\\personevent\\create.vue' /* webpackChunkName: "pages/personevent/create" */))
const _07726956 = () => interopDefault(import('..\\pages\\personlds\\create.vue' /* webpackChunkName: "pages/personlds/create" */))
const _4d651319 = () => interopDefault(import('..\\pages\\personname\\create.vue' /* webpackChunkName: "pages/personname/create" */))
const _4ca234d9 = () => interopDefault(import('..\\pages\\personnamefone\\create.vue' /* webpackChunkName: "pages/personnamefone/create" */))
const _60360c37 = () => interopDefault(import('..\\pages\\personnameromn\\create.vue' /* webpackChunkName: "pages/personnameromn/create" */))
const _79f33fbb = () => interopDefault(import('..\\pages\\personsubm\\create.vue' /* webpackChunkName: "pages/personsubm/create" */))
const _e8bc9454 = () => interopDefault(import('..\\pages\\place\\create.vue' /* webpackChunkName: "pages/place/create" */))
const _2dd8173b = () => interopDefault(import('..\\pages\\publication\\create.vue' /* webpackChunkName: "pages/publication/create" */))
const _3ae1b934 = () => interopDefault(import('..\\pages\\refn\\create.vue' /* webpackChunkName: "pages/refn/create" */))
const _1275fc03 = () => interopDefault(import('..\\pages\\repository\\create.vue' /* webpackChunkName: "pages/repository/create" */))
const _7cfe8a8c = () => interopDefault(import('..\\pages\\roles\\create.vue' /* webpackChunkName: "pages/roles/create" */))
const _c37e1c58 = () => interopDefault(import('..\\pages\\source\\create.vue' /* webpackChunkName: "pages/source/create" */))
const _42a55b04 = () => interopDefault(import('..\\pages\\sourcedata\\create.vue' /* webpackChunkName: "pages/sourcedata/create" */))
const _7c7f6798 = () => interopDefault(import('..\\pages\\sourcedataeven\\create.vue' /* webpackChunkName: "pages/sourcedataeven/create" */))
const _05d5e732 = () => interopDefault(import('..\\pages\\sourceref\\create.vue' /* webpackChunkName: "pages/sourceref/create" */))
const _4b360501 = () => interopDefault(import('..\\pages\\sourcerefeven\\create.vue' /* webpackChunkName: "pages/sourcerefeven/create" */))
const _1fc85246 = () => interopDefault(import('..\\pages\\sourcerepo\\create.vue' /* webpackChunkName: "pages/sourcerepo/create" */))
const _44300e26 = () => interopDefault(import('..\\pages\\subm\\create.vue' /* webpackChunkName: "pages/subm/create" */))
const _32b314a7 = () => interopDefault(import('..\\pages\\subn\\create.vue' /* webpackChunkName: "pages/subn/create" */))
const _63e69eba = () => interopDefault(import('..\\pages\\subscription\\index2.vue' /* webpackChunkName: "pages/subscription/index2" */))
const _3f8a9da6 = () => interopDefault(import('..\\pages\\subscription\\payment\\index.vue' /* webpackChunkName: "pages/subscription/payment/index" */))
const _31be2a8d = () => interopDefault(import('..\\pages\\subscription\\paypal.vue' /* webpackChunkName: "pages/subscription/paypal" */))
const _49b0d617 = () => interopDefault(import('..\\pages\\tree\\create.vue' /* webpackChunkName: "pages/tree/create" */))
const _08932750 = () => interopDefault(import('..\\pages\\tree\\show.vue' /* webpackChunkName: "pages/tree/show" */))
const _b74c3a42 = () => interopDefault(import('..\\pages\\forum\\topic\\_id.vue' /* webpackChunkName: "pages/forum/topic/_id" */))
const _5cf1c0e3 = () => interopDefault(import('..\\pages\\password\\reset\\_id.vue' /* webpackChunkName: "pages/password/reset/_id" */))
const _37605ce4 = () => interopDefault(import('..\\pages\\subscription\\payment\\_id.vue' /* webpackChunkName: "pages/subscription/payment/_id" */))
const _a9f53a88 = () => interopDefault(import('..\\pages\\addr\\_id.vue' /* webpackChunkName: "pages/addr/_id" */))
const _0560f0bc = () => interopDefault(import('..\\pages\\author\\_id.vue' /* webpackChunkName: "pages/author/_id" */))
const _16fe287b = () => interopDefault(import('..\\pages\\chan\\_id.vue' /* webpackChunkName: "pages/chan/_id" */))
const _837dd9f4 = () => interopDefault(import('..\\pages\\citation\\_id.vue' /* webpackChunkName: "pages/citation/_id" */))
const _4b6efa5a = () => interopDefault(import('..\\pages\\company\\_id.vue' /* webpackChunkName: "pages/company/_id" */))
const _6014aa1d = () => interopDefault(import('..\\pages\\event\\_id.vue' /* webpackChunkName: "pages/event/_id" */))
const _ea955c2e = () => interopDefault(import('..\\pages\\family\\_id.vue' /* webpackChunkName: "pages/family/_id" */))
const _7c1d927e = () => interopDefault(import('..\\pages\\familyevent\\_id.vue' /* webpackChunkName: "pages/familyevent/_id" */))
const _0ee449f8 = () => interopDefault(import('..\\pages\\familyslgs\\_id.vue' /* webpackChunkName: "pages/familyslgs/_id" */))
const _b686d790 = () => interopDefault(import('..\\pages\\forumcategory\\_id.vue' /* webpackChunkName: "pages/forumcategory/_id" */))
const _19233e5f = () => interopDefault(import('..\\pages\\forumtopic\\_id.vue' /* webpackChunkName: "pages/forumtopic/_id" */))
const _1102c218 = () => interopDefault(import('..\\pages\\mediaobject\\_id.vue' /* webpackChunkName: "pages/mediaobject/_id" */))
const _6f3ab3f8 = () => interopDefault(import('..\\pages\\mediaobjectfile\\_id.vue' /* webpackChunkName: "pages/mediaobjectfile/_id" */))
const _02df3fdb = () => interopDefault(import('..\\pages\\note\\_id.vue' /* webpackChunkName: "pages/note/_id" */))
const _6c771dd0 = () => interopDefault(import('..\\pages\\person\\_id.vue' /* webpackChunkName: "pages/person/_id" */))
const _06f4c6f5 = () => interopDefault(import('..\\pages\\personalia\\_id.vue' /* webpackChunkName: "pages/personalia/_id" */))
const _3b476a25 = () => interopDefault(import('..\\pages\\personanci\\_id.vue' /* webpackChunkName: "pages/personanci/_id" */))
const _69c377ca = () => interopDefault(import('..\\pages\\personasso\\_id.vue' /* webpackChunkName: "pages/personasso/_id" */))
const _0fdcd961 = () => interopDefault(import('..\\pages\\persondesi\\_id.vue' /* webpackChunkName: "pages/persondesi/_id" */))
const _6a9d861c = () => interopDefault(import('..\\pages\\personevent\\_id.vue' /* webpackChunkName: "pages/personevent/_id" */))
const _5d7a2131 = () => interopDefault(import('..\\pages\\personlds\\_id.vue' /* webpackChunkName: "pages/personlds/_id" */))
const _189ae026 = () => interopDefault(import('..\\pages\\personname\\_id.vue' /* webpackChunkName: "pages/personname/_id" */))
const _94c273a6 = () => interopDefault(import('..\\pages\\personnamefone\\_id.vue' /* webpackChunkName: "pages/personnamefone/_id" */))
const _351948e2 = () => interopDefault(import('..\\pages\\personnameromn\\_id.vue' /* webpackChunkName: "pages/personnameromn/_id" */))
const _729a768b = () => interopDefault(import('..\\pages\\personsubm\\_id.vue' /* webpackChunkName: "pages/personsubm/_id" */))
const _22d3a360 = () => interopDefault(import('..\\pages\\place\\_id.vue' /* webpackChunkName: "pages/place/_id" */))
const _d19e61ea = () => interopDefault(import('..\\pages\\publication\\_id.vue' /* webpackChunkName: "pages/publication/_id" */))
const _3be3d09c = () => interopDefault(import('..\\pages\\refn\\_id.vue' /* webpackChunkName: "pages/refn/_id" */))
const _66825f43 = () => interopDefault(import('..\\pages\\repository\\_id.vue' /* webpackChunkName: "pages/repository/_id" */))
const _2441f5e8 = () => interopDefault(import('..\\pages\\roles\\_id\\index.vue' /* webpackChunkName: "pages/roles/_id/index" */))
const _46eab9dc = () => interopDefault(import('..\\pages\\source\\_id.vue' /* webpackChunkName: "pages/source/_id" */))
const _388fdab0 = () => interopDefault(import('..\\pages\\sourcedata\\_id.vue' /* webpackChunkName: "pages/sourcedata/_id" */))
const _217cb864 = () => interopDefault(import('..\\pages\\sourcedataeven\\_id.vue' /* webpackChunkName: "pages/sourcedataeven/_id" */))
const _7effc95f = () => interopDefault(import('..\\pages\\sourceref\\_id.vue' /* webpackChunkName: "pages/sourceref/_id" */))
const _c45db1f6 = () => interopDefault(import('..\\pages\\sourcerefeven\\_id.vue' /* webpackChunkName: "pages/sourcerefeven/_id" */))
const _161a67e0 = () => interopDefault(import('..\\pages\\sourcerepo\\_id.vue' /* webpackChunkName: "pages/sourcerepo/_id" */))
const _03cf3800 = () => interopDefault(import('..\\pages\\subm\\_id.vue' /* webpackChunkName: "pages/subm/_id" */))
const _0fceadc2 = () => interopDefault(import('..\\pages\\subn\\_id.vue' /* webpackChunkName: "pages/subn/_id" */))
const _707d83f3 = () => interopDefault(import('..\\pages\\tree\\_id\\index.vue' /* webpackChunkName: "pages/tree/_id/index" */))
const _0baac8b6 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/addr",
    component: _2f209b54,
    name: "addr"
  }, {
    path: "/author",
    component: _17751eba,
    name: "author"
  }, {
    path: "/calendar",
    component: _6484b732,
    name: "calendar"
  }, {
    path: "/cancel",
    component: _dc5a7b92,
    name: "cancel"
  }, {
    path: "/chan",
    component: _7ffeed53,
    name: "chan"
  }, {
    path: "/chat",
    component: _39466556,
    name: "chat"
  }, {
    path: "/chatroom",
    component: _3eaac230,
    name: "chatroom"
  }, {
    path: "/citation",
    component: _6231611e,
    name: "citation"
  }, {
    path: "/company",
    component: _5b82c372,
    name: "company"
  }, {
    path: "/dashboard",
    component: _367a96e7,
    name: "dashboard"
  }, {
    path: "/dna",
    component: _6762602a,
    name: "dna"
  }, {
    path: "/dnamatching",
    component: _c627b20a,
    name: "dnamatching"
  }, {
    path: "/dnaupload",
    component: _c2256412,
    name: "dnaupload"
  }, {
    path: "/emailverification",
    component: _7e9fe0ec,
    name: "emailverification"
  }, {
    path: "/event",
    component: _4508e316,
    name: "event"
  }, {
    path: "/family",
    component: _3add197e,
    name: "family"
  }, {
    path: "/familyevent",
    component: _3a678219,
    name: "familyevent"
  }, {
    path: "/familyslgs",
    component: _3c6c219c,
    name: "familyslgs"
  }, {
    path: "/files",
    component: _1ca6ab10,
    name: "files"
  }, {
    path: "/forgotpassword",
    component: _3bf0a77b,
    name: "forgotpassword"
  }, {
    path: "/forum",
    component: _120a698e,
    name: "forum"
  }, {
    path: "/forumcategory",
    component: _d05d4460,
    name: "forumcategory"
  }, {
    path: "/forumtopic",
    component: _e593cb92,
    name: "forumtopic"
  }, {
    path: "/gedcom",
    component: _9662b46c,
    name: "gedcom"
  }, {
    path: "/gedcom-export",
    component: _6038ff49,
    name: "gedcom-export"
  }, {
    path: "/login",
    component: _785b8288,
    name: "login"
  }, {
    path: "/mediaobject",
    component: _423ba98c,
    name: "mediaobject"
  }, {
    path: "/mediaobjectfile",
    component: _8972e4e0,
    name: "mediaobjectfile"
  }, {
    path: "/note",
    component: _1010a69a,
    name: "note"
  }, {
    path: "/permissions",
    component: _6c1712ea,
    name: "permissions"
  }, {
    path: "/person",
    component: _cb54faa0,
    name: "person"
  }, {
    path: "/personalia",
    component: _4cc7d54d,
    name: "personalia"
  }, {
    path: "/personanci",
    component: _92032706,
    name: "personanci"
  }, {
    path: "/personasso",
    component: _36ada4e2,
    name: "personasso"
  }, {
    path: "/persondesi",
    component: _8816068e,
    name: "persondesi"
  }, {
    path: "/personevent",
    component: _133ec00a,
    name: "personevent"
  }, {
    path: "/personlds",
    component: _175f9089,
    name: "personlds"
  }, {
    path: "/personname",
    component: _01374045,
    name: "personname"
  }, {
    path: "/personnamefone",
    component: _0e2232f6,
    name: "personnamefone"
  }, {
    path: "/personnameromn",
    component: _f418a932,
    name: "personnameromn"
  }, {
    path: "/personsubm",
    component: _65bff763,
    name: "personsubm"
  }, {
    path: "/place",
    component: _5ca65c30,
    name: "place"
  }, {
    path: "/privacy",
    component: _626ee89b,
    name: "privacy"
  }, {
    path: "/profile",
    component: _136a563c,
    name: "profile"
  }, {
    path: "/publication",
    component: _83bba03a,
    name: "publication"
  }, {
    path: "/refn",
    component: _72602a6c,
    name: "refn"
  }, {
    path: "/register",
    component: _a478dec0,
    name: "register"
  }, {
    path: "/repository",
    component: _015edbca,
    name: "repository"
  }, {
    path: "/roles",
    component: _c0b0e31c,
    name: "roles"
  }, {
    path: "/search",
    component: _5695167d,
    name: "search"
  }, {
    path: "/source",
    component: _14571e2a,
    name: "source"
  }, {
    path: "/sourcedata",
    component: _05e70040,
    name: "sourcedata"
  }, {
    path: "/sourcedataeven",
    component: _5550dfe6,
    name: "sourcedataeven"
  }, {
    path: "/sourceref",
    component: _23c83592,
    name: "sourceref"
  }, {
    path: "/sourcerefeven",
    component: _c3e71d46,
    name: "sourcerefeven"
  }, {
    path: "/sourcerepo",
    component: _2908e778,
    name: "sourcerepo"
  }, {
    path: "/subm",
    component: _7cca2f98,
    name: "subm"
  }, {
    path: "/subn",
    component: _f7085612,
    name: "subn"
  }, {
    path: "/subscription",
    component: _6650ffa8,
    name: "subscription"
  }, {
    path: "/success",
    component: _858b60d4,
    name: "success"
  }, {
    path: "/termsandconditions",
    component: _ac971236,
    name: "termsandconditions"
  }, {
    path: "/tree",
    component: _81efb4f2,
    name: "tree"
  }, {
    path: "/verify-email",
    component: _10f11376,
    name: "verify-email"
  }, {
    path: "/addr/create",
    component: _46b1cc2c,
    name: "addr-create"
  }, {
    path: "/author/create",
    component: _0239f978,
    name: "author-create"
  }, {
    path: "/chan/create",
    component: _b0d9f06a,
    name: "chan-create"
  }, {
    path: "/citation/create",
    component: _0baf0d60,
    name: "citation-create"
  }, {
    path: "/company/create",
    component: _3c89f58c,
    name: "company-create"
  }, {
    path: "/dnaupload/create",
    component: _6670bba7,
    name: "dnaupload-create"
  }, {
    path: "/event/create",
    component: _0caaea2e,
    name: "event-create"
  }, {
    path: "/family/create",
    component: _d15d80c6,
    name: "family-create"
  }, {
    path: "/familyevent/create",
    component: _3a3d0bc5,
    name: "familyevent-create"
  }, {
    path: "/familyslgs/create",
    component: _78cc5ca2,
    name: "familyslgs-create"
  }, {
    path: "/forumcategory/create",
    component: _ebe2b224,
    name: "forumcategory-create"
  }, {
    path: "/forumtopic/create",
    component: _41417767,
    name: "forumtopic-create"
  }, {
    path: "/mediaobject/create",
    component: _2cedd2b2,
    name: "mediaobject-create"
  }, {
    path: "/mediaobjectfile/create",
    component: _558121a4,
    name: "mediaobjectfile-create"
  }, {
    path: "/note/create",
    component: _2eb2346b,
    name: "note-create"
  }, {
    path: "/pedigree/data",
    component: _7eb50b63,
    name: "pedigree-data"
  }, {
    path: "/pedigree/show",
    component: _4dd0cf02,
    name: "pedigree-show"
  }, {
    path: "/person/create",
    component: _4fe1c3e4,
    name: "person-create"
  }, {
    path: "/personalia/create",
    component: _73e71f11,
    name: "personalia-create"
  }, {
    path: "/personanci/create",
    component: _50836de1,
    name: "personanci-create"
  }, {
    path: "/personasso/create",
    component: _72897bc8,
    name: "personasso-create"
  }, {
    path: "/persondesi/create",
    component: _2b4235b6,
    name: "persondesi-create"
  }, {
    path: "/personevent/create",
    component: _7c4d8bf4,
    name: "personevent-create"
  }, {
    path: "/personlds/create",
    component: _07726956,
    name: "personlds-create"
  }, {
    path: "/personname/create",
    component: _4d651319,
    name: "personname-create"
  }, {
    path: "/personnamefone/create",
    component: _4ca234d9,
    name: "personnamefone-create"
  }, {
    path: "/personnameromn/create",
    component: _60360c37,
    name: "personnameromn-create"
  }, {
    path: "/personsubm/create",
    component: _79f33fbb,
    name: "personsubm-create"
  }, {
    path: "/place/create",
    component: _e8bc9454,
    name: "place-create"
  }, {
    path: "/publication/create",
    component: _2dd8173b,
    name: "publication-create"
  }, {
    path: "/refn/create",
    component: _3ae1b934,
    name: "refn-create"
  }, {
    path: "/repository/create",
    component: _1275fc03,
    name: "repository-create"
  }, {
    path: "/roles/create",
    component: _7cfe8a8c,
    name: "roles-create"
  }, {
    path: "/source/create",
    component: _c37e1c58,
    name: "source-create"
  }, {
    path: "/sourcedata/create",
    component: _42a55b04,
    name: "sourcedata-create"
  }, {
    path: "/sourcedataeven/create",
    component: _7c7f6798,
    name: "sourcedataeven-create"
  }, {
    path: "/sourceref/create",
    component: _05d5e732,
    name: "sourceref-create"
  }, {
    path: "/sourcerefeven/create",
    component: _4b360501,
    name: "sourcerefeven-create"
  }, {
    path: "/sourcerepo/create",
    component: _1fc85246,
    name: "sourcerepo-create"
  }, {
    path: "/subm/create",
    component: _44300e26,
    name: "subm-create"
  }, {
    path: "/subn/create",
    component: _32b314a7,
    name: "subn-create"
  }, {
    path: "/subscription/index2",
    component: _63e69eba,
    name: "subscription-index2"
  }, {
    path: "/subscription/payment",
    component: _3f8a9da6,
    name: "subscription-payment"
  }, {
    path: "/subscription/paypal",
    component: _31be2a8d,
    name: "subscription-paypal"
  }, {
    path: "/tree/create",
    component: _49b0d617,
    name: "tree-create"
  }, {
    path: "/tree/show",
    component: _08932750,
    name: "tree-show"
  }, {
    path: "/forum/topic/:id?",
    component: _b74c3a42,
    name: "forum-topic-id"
  }, {
    path: "/password/reset/:id?",
    component: _5cf1c0e3,
    name: "password-reset-id"
  }, {
    path: "/subscription/payment/:id",
    component: _37605ce4,
    name: "subscription-payment-id"
  }, {
    path: "/addr/:id",
    component: _a9f53a88,
    name: "addr-id"
  }, {
    path: "/author/:id",
    component: _0560f0bc,
    name: "author-id"
  }, {
    path: "/chan/:id",
    component: _16fe287b,
    name: "chan-id"
  }, {
    path: "/citation/:id",
    component: _837dd9f4,
    name: "citation-id"
  }, {
    path: "/company/:id",
    component: _4b6efa5a,
    name: "company-id"
  }, {
    path: "/event/:id",
    component: _6014aa1d,
    name: "event-id"
  }, {
    path: "/family/:id",
    component: _ea955c2e,
    name: "family-id"
  }, {
    path: "/familyevent/:id",
    component: _7c1d927e,
    name: "familyevent-id"
  }, {
    path: "/familyslgs/:id",
    component: _0ee449f8,
    name: "familyslgs-id"
  }, {
    path: "/forumcategory/:id",
    component: _b686d790,
    name: "forumcategory-id"
  }, {
    path: "/forumtopic/:id",
    component: _19233e5f,
    name: "forumtopic-id"
  }, {
    path: "/mediaobject/:id",
    component: _1102c218,
    name: "mediaobject-id"
  }, {
    path: "/mediaobjectfile/:id",
    component: _6f3ab3f8,
    name: "mediaobjectfile-id"
  }, {
    path: "/note/:id",
    component: _02df3fdb,
    name: "note-id"
  }, {
    path: "/person/:id",
    component: _6c771dd0,
    name: "person-id"
  }, {
    path: "/personalia/:id",
    component: _06f4c6f5,
    name: "personalia-id"
  }, {
    path: "/personanci/:id",
    component: _3b476a25,
    name: "personanci-id"
  }, {
    path: "/personasso/:id",
    component: _69c377ca,
    name: "personasso-id"
  }, {
    path: "/persondesi/:id",
    component: _0fdcd961,
    name: "persondesi-id"
  }, {
    path: "/personevent/:id",
    component: _6a9d861c,
    name: "personevent-id"
  }, {
    path: "/personlds/:id",
    component: _5d7a2131,
    name: "personlds-id"
  }, {
    path: "/personname/:id",
    component: _189ae026,
    name: "personname-id"
  }, {
    path: "/personnamefone/:id",
    component: _94c273a6,
    name: "personnamefone-id"
  }, {
    path: "/personnameromn/:id",
    component: _351948e2,
    name: "personnameromn-id"
  }, {
    path: "/personsubm/:id",
    component: _729a768b,
    name: "personsubm-id"
  }, {
    path: "/place/:id",
    component: _22d3a360,
    name: "place-id"
  }, {
    path: "/publication/:id",
    component: _d19e61ea,
    name: "publication-id"
  }, {
    path: "/refn/:id",
    component: _3be3d09c,
    name: "refn-id"
  }, {
    path: "/repository/:id",
    component: _66825f43,
    name: "repository-id"
  }, {
    path: "/roles/:id",
    component: _2441f5e8,
    name: "roles-id"
  }, {
    path: "/source/:id",
    component: _46eab9dc,
    name: "source-id"
  }, {
    path: "/sourcedata/:id",
    component: _388fdab0,
    name: "sourcedata-id"
  }, {
    path: "/sourcedataeven/:id",
    component: _217cb864,
    name: "sourcedataeven-id"
  }, {
    path: "/sourceref/:id",
    component: _7effc95f,
    name: "sourceref-id"
  }, {
    path: "/sourcerefeven/:id",
    component: _c45db1f6,
    name: "sourcerefeven-id"
  }, {
    path: "/sourcerepo/:id",
    component: _161a67e0,
    name: "sourcerepo-id"
  }, {
    path: "/subm/:id",
    component: _03cf3800,
    name: "subm-id"
  }, {
    path: "/subn/:id",
    component: _0fceadc2,
    name: "subn-id"
  }, {
    path: "/tree/:id",
    component: _707d83f3,
    name: "tree-id"
  }, {
    path: "/",
    component: _0baac8b6,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
