<template>
  <div>
    <div class="container">
      <div class="columns is-mobile is-gapless is-centered">
        <div class="page-content column is-full-mobile is-8-desktop content has-text-left">
          <div class="my-6">
            <div class="content has-text-left">
              <nav class="breadcrumb mb-2" aria-label="breadcrumbs">
                <ul class="ml-0">
                  <li><NuxtLink to="/">Home</NuxtLink></li>
                  <li class="is-active">
                    <a href="#" aria-current="page">Privacy Policy</a>
                  </li>
                </ul>
              </nav>
              <h1 class="is-size-4 has-text-black has-text-weight-bold mb-5 mt-0">
                Privacy policy
              </h1>
              <div>
                This privacy policy applies between you, the User of this Website and Family Tree 365 Ltd, the
                owner and provider of this Website. Family Tree 365 Ltd takes the privacy of your information
                very seriously. This privacy policy applies to our use of any and all Data collected by us
                or provided by you in relation to your use of the Website.
              </div>
              <div>
                This privacy policy should be read alongside, and in addition to, our Terms and
                Conditions, which can be found at: <a href="/termsandconditions" target="_blank" class="has-text-link">www.familytree365.com/termsandconditions.</a>
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Please read this privacy policy carefully.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Definitions and interpretation
              </div>
              <div> In this privacy policy, the following definitions are used: </div>
              <div>
                Data collectively all information that you submit to Family Tree 365 Ltd via the Website. This
                definition incorporates, where applicable, the definitions provided in the Data Protection
                Laws;
              </div>
              <div class="mb-3">
                Cookies a small text file placed on your computer by this Website when you visit certain
                parts of the Website and/or when you use certain features of the Website. Details of the
                cookies used by this Website are set out in the clause below ( Cookies);
              </div>
              <div class="mb-3">
                Data Protection Laws any applicable law relating to the processing of personal Data,
                including but not limited to the Directive 96/46/EC (Data Protection Directive) or the GDPR,
                and any national implementing laws, regulations and secondary legislation, for as long as
                the GDPR is effective in the UK;
              </div>
              <div class="mb-3">
                GDPR the General Data Protection Regulation (EU) 2016/679;
              </div>
              <div class="mb-3">
                Family Tree 365 Ltd, we or us Family Tree 365 Ltd, a company incorporated in England and Wales with
                registered number 12734769 whose registered office is at International House, 12 Constance
                Street, London, E16 2DQ;
              </div>
              <div class="mb-3">
                UK and EU Cookie Law the Privacy and Electronic Communications (EC Directive) Regulations
                2003 as amended by the Privacy and Electronic Communications (EC Directive) (Amendment)
                Regulations 2011;
              </div>
              <div class="mb-3">
                User or you any third party that accesses the Website and is not either (i) employed by
                Family Tree 365 Ltd and acting in the course of their employment or (ii) engaged as a consultant
                or otherwise providing services to Family Tree 365 Ltd and accessing the Website in connection
                with the provision of such services; and
              </div>
              <div class="mb-3">
                Website the website that you are currently using, www.familytree365.com, and any
                sub-domains of this site unless expressly excluded by their own terms and conditions.
              </div>
              <div class="mb-3">
                In this privacy policy, unless the context requires a different interpretation:
              </div>
              <div class="mb-3">
                the singular includes the plural and vice versa;
              </div>
              <div class="mb-3">
                references to sub-clauses, clauses, schedules or appendices are to sub-clauses, clauses,
                schedules or appendices of this privacy policy;
              </div>
              <div class="mb-3">
                a reference to a person includes firms, companies, government entities, trusts and
                partnerships;
              </div>
              <div class="mb-3">
                "including" is understood to mean "including without limitation";
              </div>
              <div class="mb-3">
                reference to any statutory provision includes any modification or amendment of it;
              </div>
              <div class="mb-3">
                the headings and sub-headings do not form part of this privacy policy.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Scope of this privacy policy
              </div>
              <div class="mb-3">
                This privacy policy applies only to the actions of Family Tree 365 Ltd and Users with respect
                to this Website. It does not extend to any websites that can be accessed from this Website
                including, but not limited to, any links we may provide to social media websites.
              </div>
              <div class="mb-3">
                For purposes of the applicable Data Protection Laws, Family Tree 365 Ltd is the "data
                controller". This means that Family Tree 365 Ltd determines the purposes for which, and the
                manner in which, your Data is processed.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Data collected
              </div>
              <div> We may collect the following Data, which includes personal Data, from you: </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                name;
              </div>
              <div class="mb-3">
                contact Information such as email addresses and telephone numbers;
              </div>
              <div class="mb-3">
                financial information such as credit / debit card numbers;
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                IP address (automatically collected);
              </div>
              <div class="mb-3">
                web browser type and version (automatically collected);
              </div>
              <div class="mb-3">
                operating system (automatically collected);
              </div>
              <div class="mb-3">
                in each case, in accordance with this privacy policy.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                How we collect Data
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                We collect Data in the following ways:
              </div>
              <div class="mb-3">
                data is given to us by you ; and
              </div>
              <div class="mb-3">
                data is collected automatically.
              </div>
              <div class="mb-3">
                Data that is given to us by you
              </div>
              <div class="mb-3">
                Family Tree 365 Ltd will collect your Data in a number of ways, for example:
              </div>
              <div class="mb-3">
                when you contact us through the Website, by telephone, post, e-mail or through any other
                means;
              </div>
              <div class="mb-3">
                when you register with us and set up an account to receive our products/services;
              </div>
              <div class="mb-3">
                when you make payments to us, through this Website or otherwise;
              </div>
              <div class="mb-3">
                when you use our services;
              </div>
              <div class="mb-3">
                in each case, in accordance with this privacy policy.
              </div>
              <div class="mb-3">
                Data that is collected automatically
              </div>
              <div class="mb-3">
                To the extent that you access the Website, we will collect your Data automatically, for
                example:
              </div>
              <div class="mb-3">
                we automatically collect some information about your visit to the Website. This
                information helps us to make improvements to Website content and navigation, and includes
                your IP address, the date, times and frequency with which you access the Website and the way
                you use and interact with its content.
              </div>
              <div class="mb-3">
                we will collect your Data automatically via cookies, in line with the cookie settings on
                your browser. For more information about cookies, and how we use them on the Website, see
                the section below, headed "Cookies".
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Our use of Data
              </div>
              <div>
                Any or all of the above Data may be required by us from time to time in order to provide
                you with the best possible service and experience when using our Website. Specifically, Data
                may be used by us for the following reasons:
              </div>
              <div class="mb-3">
                internal record keeping;
              </div>
              <div class="mb-3">
                improvement of our products / services;
              </div>
              <div class="mb-3">
                in each case, in accordance with this privacy policy.
              </div>
              <div class="mb-3">
                We may use your Data for the above purposes if we deem it necessary to do so for our
                legitimate interests. If you are not satisfied with this, you have the right to object in
                certain circumstances (see the section headed "Your rights" below).
              </div>
              <div class="mb-3">
                When you register with us and set up an account to receive our services, the legal basis
                for this processing is the performance of a contract between you and us and/or taking steps,
                at your request, to enter into such a contract.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Who we share Data with
              </div>
              <div class="mb-3">
                We may share your Data with the following groups of people for the following reasons:
              </div>
              <div class="mb-3">
                third party payment providers who process payments made over the Website - to enable third
                party payment providers to process user payments and refunds;
              </div>
              <div class="mb-3">
                in each case, in accordance with this privacy policy.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Keeping Data secure
              </div>
              <div class="mb-3">
                We will use technical and organisational measures to safeguard your Data, for example:
              </div>
              <div class="mb-3">
                access to your account is controlled by a password and a user name that is unique to you.
              </div>
              <div class="mb-3">
                we store your Data on secure servers.
              </div>
              <div class="mb-3">
                payment details are encrypted using SSL technology (typically you will see a lock icon or
                green address bar (or both) in your browser when we use this technology.
              </div>
              <div class="mb-3">
                We are certified to PCI DSS. This family of standards helps us manage your Data and keep
                it secure.
              </div>
              <div class="mb-3">
                Technical and organisational measures include measures to deal with any suspected data
                breach. If you suspect any misuse or loss or unauthorised access to your Data, please let us
                know immediately by contacting us via this e-mail address: support@familytree365.com.
              </div>
              <div class="mb-3">
                If you want detailed information from Get Safe Online on how to protect your information
                and your computers and devices against fraud, identity theft, viruses and many other online
                problems, please visit www.getsafeonline.org. Get Safe Online is supported by HM Government
                and leading businesses.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Data retention
              </div>
              <div class="mb-3">
                Unless a longer retention period is required or permitted by law, we will only hold your
                Data on our systems for the period necessary to fulfil the purposes outlined in this privacy
                policy or until you request that the Data be deleted.
              </div>
              <div class="mb-3">
                Even if we delete your Data, it may persist on backup or archival media for legal, tax or
                regulatory purposes.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Your rights
              </div>
              <div class="mb-3">
                You have the following rights in relation to your Data:
              </div>
              <div class="mb-3">
                Right to access - the right to request (i) copies of the information we hold about you at
                any time, or (ii) that we modify, update or delete such information. If we provide you with
                access to the information we hold about you, we will not charge you for this, unless your
                request is "manifestly unfounded or excessive." Where we are legally permitted to do so, we
                may refuse your request. If we refuse your request, we will tell you the reasons why.
              </div>
              <div class="mb-3">
                Right to correct - the right to have your Data rectified if it is inaccurate or
                incomplete.
              </div>
              <div class="mb-3">
                Right to erase - the right to request that we delete or remove your Data from our systems.
              </div>
              <div class="mb-3">
                Right to restrict our use of your Data - the right to "block" us from using your Data or
                limit the way in which we can use it.
              </div>
              <div class="mb-3">
                Right to data portability - the right to request that we move, copy or transfer your Data.
              </div>
              <div class="mb-3">
                Right to object - the right to object to our use of your Data including where we use it
                for our legitimate interests.
              </div>
              <div class="mb-3">
                To make enquiries, exercise any of your rights set out above, or withdraw your consent to
                the processing of your Data (where consent is our legal basis for processing your Data),
                please contact us via this e-mail address: support@familytree365.com.
              </div>
              <div class="mb-3">
                If you are not satisfied with the way a complaint you make in relation to your Data is
                handled by us, you may be able to refer your complaint to the relevant data protection
                authority. For the UK, this is the Information Commissioner's Office (ICO). The ICO's
                contact details can be found on their website at https://ico.org.uk/.
              </div>
              <div class="mb-3">
                It is important that the Data we hold about you is accurate and current. Please keep us
                informed if your Data changes during the period for which we hold it.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Links to other websites
              </div>
              <div>
                This Website may, from time to time, provide links to other websites. We have no control
                over such websites and are not responsible for the content of these websites. This privacy
                policy does not extend to your use of such websites. You are advised to read the privacy
                policy or statement of other websites prior to using them.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Changes of business ownership and control
              </div>
              <div>
                Family Tree 365 Ltd may, from time to time, expand or reduce our business and this may involve
                the sale and/or the transfer of control of all or part of Family Tree 365 Ltd. Data provided by
                Users will, where it is relevant to any part of our business so transferred, be transferred
                along with that part and the new owner or newly controlling party will, under the terms of
                this privacy policy, be permitted to use the Data for the purposes for which it was
                originally supplied to us.
              </div>
              <div>
                We may also disclose Data to a prospective purchaser of our business or any part of it.
              </div>
              <div>
                In the above instances, we will take steps with the aim of ensuring your privacy is
                protected.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Cookies
              </div>
              <div class="mb-3">
                This Website may place and access certain Cookies on your computer. Family Tree 365 Ltd uses
                Cookies to improve your experience of using the Website and to improve our range of
                services. Family Tree 365 Ltd has carefully chosen these Cookies and has taken steps to ensure
                that your privacy is protected and respected at all times.
              </div>
              <div class="mb-3">
                All Cookies used by this Website are used in accordance with current UK and EU Cookie Law.
              </div>
              <div class="mb-3">
                Before the Website places Cookies on your computer, you will be presented with a message
                bar requesting your consent to set those Cookies. By giving your consent to the placing of
                Cookies, you are enabling Family Tree 365 Ltd to provide a better experience and service to you.
                You may, if you wish, deny consent to the placing of Cookies; however certain features of
                the Website may not function fully or as intended.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-bold my-5">
                This Website may place the following Cookies:
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Type of Cookie Purpose
              </div>
              <div class="mb-3">
                Strictly necessary cookies These are cookies that are required for the operation of our
                website. They include, for example, cookies that enable you to log into secure areas of our
                website, use a shopping cart or make use of e-billing services.
              </div>
              <div class="mb-3">
                You can find a list of Cookies that we use in the Cookies Schedule.
              </div>
              <div class="mb-3">
                You can choose to enable or disable Cookies in your internet browser. By default, most
                internet browsers accept Cookies but this can be changed. For further details, please
                consult the help menu in your internet browser.
              </div>
              <div class="mb-3">
                You can choose to delete Cookies at any time; however you may lose any information that
                enables you to access the Website more quickly and efficiently including, but not limited
                to, personalisation settings.
              </div>
              <div class="mb-3">
                It is recommended that you ensure that your internet browser is up-to-date and that you
                consult the help and guidance provided by the developer of your internet browser if you are
                unsure about adjusting your privacy settings.
              </div>
              <div class="mb-3">
                For more information generally on cookies, including how to disable them, please refer to
                aboutcookies.org. You will also find details on how to delete cookies from your computer.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                General
              </div>
              <div class="mb-3">
                You may not transfer any of your rights under this privacy policy to any other person. We
                may transfer our rights under this privacy policy where we reasonably believe your rights
                will not be affected.
              </div>
              <div class="mb-3">
                If any court or competent authority finds that any provision of this privacy policy (or
                part of any provision) is invalid, illegal or unenforceable, that provision or
                part-provision will, to the extent required, be deemed to be deleted, and the validity and
                enforceability of the other provisions of this privacy policy will not be affected.
              </div>
              <div class="mb-3">
                Unless otherwise agreed, no delay, act or omission by a party in exercising any right or
                remedy will be deemed a waiver of that, or any other, right or remedy.
              </div>
              <div>
                This Agreement will be governed by and interpreted according to the law of England and
                Wales. All disputes arising under the Agreement will be subject to the exclusive
                jurisdiction of the English and Welsh courts.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Changes to this privacy policy
              </div>
              <div>
                Family Tree 365 Ltd reserves the right to change this privacy policy as we may deem necessary
                from time to time or as may be required by law. Any changes will be immediately posted on
                the Website and you are deemed to have accepted the terms of the privacy policy on your
                first use of the Website following the alterations. You may contact Family Tree 365 Ltd by email
                at <a href="mailto:support@familytree365.com" class="has-text-link">support@familytree365.com.</a>
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Cookies
              </div>
              <div>
                Below is a list of the cookies that we use. We have tried to ensure this is complete and
                up to date, but if you think that we have missed a cookie or there is any discrepancy,
                please let us know.
              </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Strictly necessary
              </div>
              <div> We use the following strictly necessary cookies: </div>
              <div class="is-size-6 has-text-black has-text-weight-medium my-5">
                Description of Cookie Purpose
              </div>
              <div>
                Session cookie We use this session cookie to remember you and maintain your session whilst
                you are using our website.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <footer class="px-5 footer">
        <div class="container">
            <div class="footer-cta columns is-gapless mb-0 pb-6">
                <div class="column is-7">
                    <h1 class="is-size-2 has-text-primary has-text-weight-bold mb-3">
                        Start Your Free Tree Now!
                    </h1>
                    <div class="is-size-6 has-text-white has-text-weight-regular">
                      Your first tree is 100% free! If you need more, we offer affordable upgrades via our simple subscription plans.
                      Need help? We can assist you to get started and explain Family Tree 365 features. Any issues? You can always contact our support team.
                    </div>
                </div>
                <div class="footer-action column is-5 is-flex ai--c jc--fe">
                    <NuxtLink to="/register" v-if="!isAuthenticated"
                        class="button theme-button theme-button-xl has-background-primary has-text-weight-medium has-text-white">
                        Create Your Own Tree
                    </NuxtLink>
                </div>
            </div>
            <div class="footer-seprator"></div>
            <div class="columns is-multiline is-variable is-6 py-6 mb-0">
                <div class="column is-4">
                    <img src="~assets/images/footer-logo.svg" width="180px" class="mb-5">
                    <div class="is-size-7 has-text-light has-text-weight-regular" style="line-height: 1.4rem;">
                        Copyright &copy; Family Tree 365 Ltd,<br> Unit A, 82 James Carter Road, Mildenhall, Suffolk, England, IP28 7DE<br> Company
                        number 12734769
                    </div>
                    <p class="mt-2">
                        <a href="https://www.facebook.com/familytree365" target="_blank" class="is-size-7 has-text-link is-flex">
                            <i class="fab fa-facebook mr-2" style="margin-top: 0.2rem;"></i>Follow us on Facebook </a>
                        </p>
                </div>
                <div class="column is-5">
                    <h1 class="is-size-5 has-text-white has-text-weight-bold mb-5">
                        Quick Links
                    </h1>
                    <div class="columns is-gapless is-multiline is-flex fd--r">
                        <div class="column is-flex fd--c">
                            <NuxtLink to="/" class="is-size-7 has-text-link mb-2">Home</NuxtLink>
                            <a href="#features" class="is-size-7 has-text-link mb-2">Features</a>
                            <a href="#why" class="is-size-7 has-text-link mb-2">Why Family Tree 365?</a>
                            <a href="#" class="is-size-7 has-text-link mb-2">About</a>
                        </div>
                        <div class="column is-flex fd--c">
                            <NuxtLink to="/login" class="is-size-7 has-text-link mb-2">Sign in</NuxtLink>
                            <NuxtLink to="/privacy" class="is-size-7 has-text-link mb-2">Privacy Policy</NuxtLink>
                            <NuxtLink to="/termsandconditions" class="is-size-7 has-text-link mb-2">Terms &amp; Conditions</NuxtLink>
                        </div>
                    </div>
                </div>
                <div class="column is-3">
                    <h1 class="is-size-5 has-text-white has-text-weight-bold mb-5">
                        Contact Details
                    </h1>
                    <div class="is-flex ml-1 mb-4">
                        <i class="fas fa-envelope mr-2 has-text-primary"></i>
                        <a href="mailto:support@familytree365.com" class="is-size-7 has-text-link">
                            support@familytree365.com</a>
                    </div>
                    <div class="is-flex mb-4">
                        <!-- <img src="img/mobile.svg" alt="" class="ml-2 mr-2"> -->
                        <i class="fas fa-mobile-alt ml-2 mr-2 has-text-primary"></i>
                        <a href="tel:+44 20 8064 1187" class="is-size-7 has-text-link is-flex">
                          +44 20 8064 1187</a>
                    </div>
                    <div class="is-flex ml-1 mb-5">
                        <i class="fab fa-whatsapp mr-2 has-text-primary"></i>
                        <a href="https://api.whatsapp.com/send?phone=+44 20 8064 1187"
                            class="is-size-7 has-text-link is-flex">
                            +44 20 8064 1187</a>
                    </div>
                </div>
            </div>
            <div class="footer-seprator"></div>
            <div class="content has-text-centered pt-6">
                <div class="columns is-gapless">
                    <div class="column has-text-centered is-flex-desktop-only">
                        <p class="is-size-7 has-text-light has-text-weight-regular">Copyright &copy; {{ new Date().getFullYear() }} Family Tree 365 Ltd</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
  </div>
</template>
<script>
    import { mapGetters } from 'vuex'
export default {
    data() {
        return {
            isDark: false,
            isClear: true,
        };
    },
    computed: {
         ...mapGetters([
              'isAuthenticated',
              'loggedInUser','isAuthenticated', 'loggedInUser'])
    },
    created() {
        window.addEventListener('scroll', this.handleScroll);
    },
    methods: {
        async logout() {
          await this.$auth.logout();
        },
        handleScroll() {
            if (window.scrollY >= 500) {
                this.isClear = false;
                this.isDark = true;
            } else {
                this.isClear = true;
                this.isDark = false;
            }
        },
    },
}
</script>

 <style scoped>
    @import '~/assets/css/base.css';
</style>

